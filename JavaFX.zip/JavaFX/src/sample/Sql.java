package sample;

import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Sql{
    public static final boolean READ = true;
    public static final boolean WRITE = false;
    public static final int DEFAULT_PORT = 3306;
    protected String ActiveTable;
    protected Connection con = null;
    protected Statement statement = null;
    protected PreparedStatement preparedStatement = null;
    protected ResultSet resultSet = null;

    Sql(String host, int port, String DataBase, String ID, String Passwd)
    {
        try {
            /*
            String curl = "jdbc:sqlserver://yourserver.database.windows.net:1433;"
                    + "database=AdventureWorks;"
                    + "user=yourusername@yourserver;"
                    + "password=yourpassword;"
                    + "encrypt=true;"
                    + "trustServerCertificate=false;"
                    + "loginTimeout=30;";
                    */

            con = DriverManager.getConnection("jdbc:mysql://" +host +":" +port +"/" +DataBase +"?serverTimezone=UTC", ID, Passwd);
            //con = DriverManager.getConnection(curl);
        } catch (SQLException e) {
            System.out.print("Błąd: nie udało się połączyć, serwer nie odpowiada");
            System.out.print(e);
        }
    }
    public void readDataBase(ObservableList<DataWorkers> data) throws Exception {
        statement = con.createStatement();
        this.resultSet = statement.executeQuery("select * from inwentaryzacja.pracownicy");
        try {
            //lista string do resultSet
            while(resultSet.next())
            {
                String id = resultSet.getString("id");
                String nazwisko = resultSet.getString("nazwisko");
                String imie = resultSet.getString("imie");
                DataWorkers tmp = new DataWorkers(id, imie, nazwisko);
                data.add(tmp);
                //System.out.println(id + " " + nazwisko);
            }
        } catch (Exception e) {
            System.out.print("Błąd: nie udało się połączyć, serwer nie odpowiada");
        }
    }
    public void readDataBase2(ObservableList<DataDevices> data) throws Exception {
        statement = con.createStatement();
        this.resultSet = statement.executeQuery("select * from inwentaryzacja.sprzet");
        try {
            //lista string do resultSet
            while(resultSet.next())
            {
                String id = resultSet.getString("id");
                String nazwa = resultSet.getString("nazwa");
                String dataZakupu = resultSet.getString("data_zakupu");
                DataDevices tmp = new DataDevices(id, nazwa, dataZakupu);
                data.add(tmp);
                //System.out.println(id + " " + nazwa +" " +dataZakupu);
            }
        } catch (Exception e) {
            System.out.print("Błąd: nie udało się połączyć, serwer nie odpowiada");
        }
    }
    public void readDataBase3(ObservableList<DataWydaj> data) throws Exception {
        statement = con.createStatement();
        this.resultSet = statement.executeQuery("select * from inwentaryzacja.wydania");
        try {
            //lista string do resultSet
            while(resultSet.next())
            {
                String wyd_id = resultSet.getString("wydania_id");
                String prac_id = resultSet.getString("pracownik_id");
                String dataWydania = resultSet.getString("data_wydania");
                String sprzet_id = resultSet.getString("sprzet_id");
                DataWydaj tmp = new DataWydaj(wyd_id, prac_id, dataWydania, sprzet_id);
                data.add(tmp);
                //System.out.println(id + " " + nazwa +" " +dataZakupu);
            }
        } catch (Exception e) {
            System.out.print("Błąd: nie udało się połączyć, serwer nie odpowiada");
        }
    }
    public void readDataBase4(ObservableList<DataZwroc> data) throws Exception {
        statement = con.createStatement();
        this.resultSet = statement.executeQuery("select * from inwentaryzacja.zwroty");
        try {
            //lista string do resultSet
            while(resultSet.next())
            {
                String zwrot_id = resultSet.getString("zwrot_id");
                String sprzet_id = resultSet.getString("sprzet_id");
                String prac_id = resultSet.getString("pracownik_id");
                String wyd_id = resultSet.getString("wydanie_id");
                String dataWydania = resultSet.getString("data_zwrotu");

                DataZwroc tmp = new DataZwroc(zwrot_id, sprzet_id,
                        prac_id, wyd_id, dataWydania);
                data.add(tmp);
                //System.out.println(id + " " + nazwa +" " +dataZakupu);
            }
        } catch (Exception e) {
            System.out.print("Błąd: nie udało się połączyć, serwer nie odpowiada");
        }
    }
    public void writeToWydania(String pracId, String sprzetId) throws Exception {
        try {
            statement = null;
            preparedStatement = null;
            resultSet = null;
            String query2 = "INSERT INTO inwentaryzacja.wydania VALUES(default, " +pracId +", CURRENT_DATE(), "+sprzetId +")";
            preparedStatement = con.prepareStatement(query2);
            preparedStatement.execute();

        } catch (Exception e) {
            System.out.println("Błąd: nie udało się połączyć, serwer nie odpowiada");
        }
    }

    public void query(String query, boolean WRITE_OR_READ)
    {
        if(READ)
        {
            try {
                statement = con.createStatement();
                this.resultSet = statement.executeQuery(query);

            } catch (SQLException e) {
                System.out.print("Błędne zapytanie!");
            }
        }
        else
        {
            try {
                preparedStatement = con.prepareStatement(query);
                this.resultSet = preparedStatement.executeQuery();
            } catch (SQLException e) {
                System.out.print("Błędne zapytanie!");
            }
        }

    }
    void UseTable(String TableName)
    {
        this.ActiveTable = TableName;
    }
    // You need to close the resultSet
    public void close() {
        try {
            if (resultSet != null) {
                resultSet.close();
            }

            if (statement != null) {
                statement.close();
            }

            if (con != null) {
                con.close();
            }
        } catch (Exception e) {
            System.out.println("Błąd zamykania!");
        }
    }

}

//https://www.sqlshack.com/learn-sql-sql-script/
