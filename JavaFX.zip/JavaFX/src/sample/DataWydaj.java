package sample;

import javafx.beans.property.SimpleStringProperty;

public class DataWydaj {
    public final SimpleStringProperty wyd_id;
    public final SimpleStringProperty prac_id;
    public final SimpleStringProperty data_wydan;
    public final SimpleStringProperty sprze_id;

    protected DataWydaj(String wydania_id, String pracownik_id,
                        String data_wydania, String sprzet_id) {
        this.wyd_id = new SimpleStringProperty(wydania_id);
        this.prac_id = new SimpleStringProperty(pracownik_id);
        this.data_wydan = new SimpleStringProperty(data_wydania);
        this.sprze_id = new SimpleStringProperty(sprzet_id);
    }

    public String getWydID() {
        return wyd_id.get();
    }
    public void setWydID(String id) {
        wyd_id.set(id);
    }

    public String getPracID() {
        return prac_id.get();
    }
    public void setPracID(String id) {
        prac_id.set(id);
    }

    public String getDataWyd() {
        return data_wydan.get();
    }
    public void setDataWyd(String Data) {
        data_wydan.set(Data);
    }

    public String getSprzetID() {
        return sprze_id.get();
    }
    public void setSprzetID(String Data) {
        sprze_id.set(Data);
    }

}