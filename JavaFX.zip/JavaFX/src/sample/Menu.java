package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Menu {
    void Menu(){}
    void CreateMenu(Stage primaryStage)
    {
        Image imgWorkers = new Image("sample/human_icon.png");
        Image imgDevices = new Image("sample/Devices_icon.png");
        Image imgWydajDevice = new Image("sample/WydajDevice.png");
        Image imgZwrocDevice = new Image("sample/zwrocDevice.png");
        ImageView view = new ImageView(imgWorkers);
        ImageView view2 = new ImageView(imgDevices);
        ImageView view3 = new ImageView(imgWydajDevice);
        ImageView view4 = new ImageView(imgZwrocDevice);
        view.setFitHeight(80);
        view2.setFitHeight(80);
        view3.setFitHeight(80);
        view4.setFitHeight(80);
        view.setPreserveRatio(true);
        view2.setPreserveRatio(true);
        view3.setPreserveRatio(true);
        view4.setPreserveRatio(true);

        Button buttonPracownicy = new Button();
        buttonPracownicy.setTranslateX(-140);
        buttonPracownicy.setTranslateY(0);
        buttonPracownicy.setPrefSize(80, 80);
        buttonPracownicy.setGraphic(view);


        buttonPracownicy.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                TableWorkers workers = new TableWorkers();
                workers.show(primaryStage);
            }
        });

        Button buttonDevices = new Button();
        buttonDevices.setPrefSize(80, 80);
        buttonDevices.setGraphic(view2);

        buttonDevices.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                TableDevices devices = new TableDevices();
                devices.show(primaryStage);
            }
        });

        Button wydajDevice = new Button();
        wydajDevice.setTranslateX(140);
        wydajDevice.setTranslateY(0);
        wydajDevice.setPrefSize(80, 80);
        wydajDevice.setGraphic(view3);


        wydajDevice.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                TableWydaj wydane = new TableWydaj();
                wydane.show(primaryStage);
            }
        });

        Button zwrocDevice = new Button();
        zwrocDevice.setTranslateX(280);
        zwrocDevice.setTranslateY(0);
        zwrocDevice.setPrefSize(80, 80);
        zwrocDevice.setGraphic(view4);


        zwrocDevice.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                TableZwroc device = new TableZwroc();
                device.show(primaryStage);
            }
        });


        StackPane root = new StackPane();
        root.getChildren().add(buttonPracownicy);
        root.getChildren().add(buttonDevices);
        root.getChildren().add(wydajDevice);
        root.getChildren().add(zwrocDevice);

        Scene scene = new Scene(root, 750, 250);

        primaryStage.setTitle("Inwentaryzacja sprzętu");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
