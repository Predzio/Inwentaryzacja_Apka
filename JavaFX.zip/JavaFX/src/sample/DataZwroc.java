package sample;

import javafx.beans.property.SimpleStringProperty;

public class DataZwroc {
    public final SimpleStringProperty zwrot_id;
    public final SimpleStringProperty sprzet_id;
    public final SimpleStringProperty pracownik_id;
    public final SimpleStringProperty wydanie_id;
    public final SimpleStringProperty data_zwrotu;

    protected DataZwroc(String zwrot_id, String sprzet_id,
                        String pracownik_id, String wydanie_id,
                        String data_zwrotu) {
        this.zwrot_id = new SimpleStringProperty(zwrot_id);
        this.sprzet_id = new SimpleStringProperty(sprzet_id);
        this.pracownik_id = new SimpleStringProperty(pracownik_id);
        this.wydanie_id = new SimpleStringProperty(wydanie_id);
        this.data_zwrotu = new SimpleStringProperty(data_zwrotu);
    }

    public String getZwrot_id() {
        return zwrot_id.get();
    }
    public void setZwrot_id(String id) {
        sprzet_id.set(id);
    }

    public String getSprzet_id() {
        return sprzet_id.get();
    }
    public void setSprzet_id(String id) {
        sprzet_id.set(id);
    }

    public String getPracownik_id() {
        return pracownik_id.get();
    }
    public void setPracownik_id(String id) {
        pracownik_id.set(id);
    }

    public String getWydanie_id() {
        return wydanie_id.get();
    }
    public void setWydanie_id(String id) {
        wydanie_id.set(id);
    }

    public String getDataZwrotu() {
        return data_zwrotu.get();
    }
    public void setDataZwrotu(String Date) {
        data_zwrotu.set(Date);
    }

}
