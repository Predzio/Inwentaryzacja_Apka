package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class TableWydaj {
    private TableView<DataWydaj> table = new TableView<DataWydaj>();
    private ObservableList<DataWydaj> data =
            FXCollections.observableArrayList();

    //Wyświetla tabelę sprzętu
    void show(final Stage primaryStage)
    {
        Scene secondScene = new Scene(new Group());
        Stage Wydaj = new Stage();
        Wydaj.setTitle("Table1");
        Wydaj.setWidth(450);
        Wydaj.setHeight(700);

        final Label label = new Label("Wydane sprzęty:");
        label.setFont(new Font("Arial", 20));

        /* Laczenie z baza */
        Sql wyd = new Sql("localhost", 3306, "inwentaryzacja", "root", "zaq1@WSX");
        try {
            wyd.readDataBase3(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        wyd.close();
        /* Koniec laczenia z baza */

        table.setEditable(true);

        TableColumn ID = new TableColumn("Wydania_id");
        ID.setMinWidth(100);
        ID.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("ID"));

        TableColumn Name = new TableColumn("Pracownik_id");
        Name.setMinWidth(100);
        /*Name.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("prac_id"));*/

        TableColumn Date = new TableColumn("Data wydania");
        Date.setMinWidth(100);
        /*Date.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("Date"));*/

        TableColumn Sprzet = new TableColumn("Sprzet_id");
        Date.setMinWidth(100);
        /*Date.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("Device"));*/

        table.setItems(data);
        table.getColumns().addAll(ID, Name, Date, Sprzet);
/*
        final Label l1 = new Label("ID pracownika:");
        label.setFont(new Font("Arial", 20));
        TextField field1 = new TextField();

        final Label l2 = new Label("ID sprzętu:");
        label.setFont(new Font("Arial", 20));
        TextField field2 = new TextField();

        Button btnWydaj = new Button();
        btnWydaj.setText("Wydaj");

        btnWydaj.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                Sql w = new Sql("localhost", 3306, "inwentaryzacja", "root", "zaq1@WSX");
                try {
                    w.writeToWydania(field1.getText(), field2.getText());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                w.close();

            }
        });
*/
        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(label, table);//, l1,field1, l2, field2, btnWydaj

        ((Group) secondScene.getRoot()).getChildren().addAll(vbox);

        Wydaj.setScene(secondScene);
        Wydaj.initModality(Modality.WINDOW_MODAL);
        Wydaj.initOwner(primaryStage);
        Wydaj.show();
    }
}