package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;


public class TableWorkers {
    private TableView<DataWorkers> table = new TableView<DataWorkers>();
    private ObservableList<DataWorkers> data =
            FXCollections.observableArrayList();

    //Wyświetla tabelę pracownicy
    void show(final Stage primaryStage)
    {
        Scene secondScene = new Scene(new Group());
        Stage Pracownicy = new Stage();
        Pracownicy.setTitle("Tabela pracowników");
        final Label label = new Label("Pracownicy");
        label.setFont(new Font("Arial", 20));

        /* Laczenie z baza */
        Sql pracownicy = new Sql("localhost", 3306, "inwentaryzacja", "root", "zaq1@WSX");
        try {
            pracownicy.readDataBase(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        pracownicy.close();
        /* Koniec laczenia z baza */

        table.setEditable(true);

        TableColumn firstNameCol = new TableColumn("ID");
        firstNameCol.setMinWidth(100);
        firstNameCol.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("ID"));

        TableColumn lastNameCol = new TableColumn("Nazwisko");
        lastNameCol.setMinWidth(100);
        lastNameCol.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("LastName"));

        TableColumn fName = new TableColumn("Imię");
        fName.setMinWidth(200);
        fName.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("FirstName"));

        table.setItems(data);
        table.getColumns().addAll(firstNameCol, lastNameCol, fName);

        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(label, table);

        ((Group) secondScene.getRoot()).getChildren().addAll(vbox);

        Pracownicy.setScene(secondScene);
        Pracownicy.initModality(Modality.WINDOW_MODAL);
        Pracownicy.initOwner(primaryStage);
        Pracownicy.show();
    }
}
