package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class TableZwroc {
    private TableView<DataZwroc> table = new TableView<DataZwroc>();
    private ObservableList<DataZwroc> data =
            FXCollections.observableArrayList();

    //Wyświetla tabelę sprzętu
    void show(final Stage primaryStage)
    {
        Scene secondScene = new Scene(new Group());
        Stage Wydaj = new Stage();
        Wydaj.setTitle("Table1");
        Wydaj.setWidth(450);
        Wydaj.setHeight(700);

        final Label label = new Label("Zwrócone:");
        label.setFont(new Font("Arial", 20));

        /* Laczenie z baza */
        Sql sprzet = new Sql("localhost", 3306, "inwentaryzacja", "root", "zaq1@WSX");
        try {
            sprzet.readDataBase4(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        sprzet.close();
        /* Koniec laczenia z baza */

        table.setEditable(true);

        TableColumn Zwrot = new TableColumn("Zwrot_id");
        Zwrot.setMinWidth(100);
        Zwrot.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("zwrot_id"));

        TableColumn Sprzet = new TableColumn("Sprzet_id");
        Sprzet.setMinWidth(100);
        Sprzet.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("sprzet_id"));

        TableColumn Pracownik = new TableColumn("Pracownik_id");
        Pracownik.setMinWidth(100);
        Pracownik.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("pracownik_id"));

        TableColumn Wydanie = new TableColumn("Sprzet_id");
        Wydanie.setMinWidth(100);
        Wydanie.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("wydanie_id"));

        TableColumn Data = new TableColumn("Sprzet_id");
        Data.setMinWidth(100);
        Data.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("Data"));

        table.setItems(data);
        table.getColumns().addAll(Zwrot, Sprzet, Pracownik, Wydanie, Data);

        final Label l1 = new Label("ID pracownika:");
        label.setFont(new Font("Arial", 20));
        TextField field1 = new TextField();

        final Label l2 = new Label("ID sprzętu:");
        label.setFont(new Font("Arial", 20));
        TextField field2 = new TextField();

        Button btnWydaj = new Button();
        btnWydaj.setText("Zwróć");

        btnWydaj.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                /*
                Sql w = new Sql("localhost", 3306, "inwentaryzacja", "root", "zaq1@WSX");
                try {
                    w.writeToWydania(field1.getText(), field2.getText());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                w.close();
                */
            }
        });

        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(label, table, l1,
                field1, l2, field2, btnWydaj);

        ((Group) secondScene.getRoot()).getChildren().addAll(vbox);

        Wydaj.setScene(secondScene);
        Wydaj.initModality(Modality.WINDOW_MODAL);
        Wydaj.initOwner(primaryStage);
        Wydaj.show();
    }
}
