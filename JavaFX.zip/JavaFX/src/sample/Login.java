package sample;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Login{
    String id;
    String pass;
    Stage primaryStage;

    Login(Stage primaryStage, Menu menu)
    {
        this.primaryStage= primaryStage;
        Label loginText = new Label("Login: ");
        TextField login = new TextField();
        //login.setTranslateX(0);
        //login.setTranslateY(0);
        login.setPrefSize(50, 10);

        Label passText = new Label("Login: ");
        final PasswordField password = new PasswordField();
        //login.setTranslateX(0);
        //login.setTranslateY(100);
        login.setPrefSize(50, 10);

        Button LogIn = new Button();
        //LogIn.setTranslateX(0);
        //LogIn.setTranslateY(100);
        LogIn.setPrefSize(80, 20);
        LogIn.setText("Zaloguj");

        LogIn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                menu.CreateMenu(primaryStage);
            }
        });
        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(loginText, login, passText,
                password, LogIn);

        //StackPane root = new StackPane();
        //root.getChildren().add(login);
        //root.getChildren().add(password);
        //root.getChildren().add(LogIn);
        Scene scene = new Scene(new Group());
        ((Group) scene.getRoot()).getChildren().addAll(vbox);
        primaryStage.setTitle("Inwentaryzacja sprzętu");
        primaryStage.setScene(scene);
        primaryStage.show();

    }
}
