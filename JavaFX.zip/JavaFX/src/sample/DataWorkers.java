package sample;

import javafx.beans.property.SimpleStringProperty;

public class DataWorkers {
    public final SimpleStringProperty ID;
    public final SimpleStringProperty FirstName;
    public final SimpleStringProperty LastName;

    protected DataWorkers(String id, String fName, String lName) {
        this.ID = new SimpleStringProperty(id);
        this.FirstName = new SimpleStringProperty(fName);
        this.LastName = new SimpleStringProperty(lName);
    }

    public String getID() {
        return ID.get();
    }
    public void setID(String id) {
        ID.set(id);
    }

    public String getFirstName() {
        return FirstName.get();
    }
    public void setFirstName(String fName) {
        FirstName.set(fName);
    }

    public String getLastName() {
        return LastName.get();
    }
    public void setLastName(String lName) {
        LastName.set(lName);
    }

}
