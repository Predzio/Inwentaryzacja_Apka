package sample;

import javafx.beans.property.SimpleStringProperty;

public class DataDevices {
    public final SimpleStringProperty ID;
    public final SimpleStringProperty Name;
    public final SimpleStringProperty DatePurchase;

    protected DataDevices(String id, String Name, String DatePurchase) {
        this.ID = new SimpleStringProperty(id);
        this.Name = new SimpleStringProperty(Name);
        this.DatePurchase = new SimpleStringProperty(DatePurchase);
    }

    public String getID() {
        return ID.get();
    }
    public void setID(String id) {
        ID.set(id);
    }

    public String getName() {
        return Name.get();
    }
    public void setName(String fName) {
        Name.set(fName);
    }

    public String getDatePurchase() {
        return DatePurchase.get();
    }
    public void setDatePurchase(String lName) {
        DatePurchase.set(lName);
    }
}
