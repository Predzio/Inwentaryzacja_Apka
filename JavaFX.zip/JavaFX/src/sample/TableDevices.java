package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class TableDevices {
    private TableView<DataDevices> table = new TableView<DataDevices>();
    private ObservableList<DataDevices> data =
            FXCollections.observableArrayList();

    //Wyświetla tabelę sprzętu
    void show(final Stage primaryStage)
    {
        Scene secondScene = new Scene(new Group());
        Stage Devices = new Stage();
        Devices.setTitle("Tabela sprzętu");
        Devices.setWidth(450);
        Devices.setHeight(500);

        final Label label = new Label("Sprzęt");
        label.setFont(new Font("Arial", 20));

        /* Laczenie z baza */
        Sql sprzet = new Sql("localhost", 3306, "inwentaryzacja", "root", "zaq1@WSX");
        try {
            sprzet.readDataBase2(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        sprzet.close();
        /* Koniec laczenia z baza */

        table.setEditable(true);

        TableColumn ID = new TableColumn("ID");
        ID.setMinWidth(100);
        ID.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("ID"));

        TableColumn Name = new TableColumn("Nazwa");
        Name.setMinWidth(100);
        Name.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("Name"));

        TableColumn Date = new TableColumn("Data zakupu");
        Date.setMinWidth(100);
        Date.setCellValueFactory(
                new PropertyValueFactory<DataWorkers, String>("DatePurchase"));

        table.setItems(data);
        table.getColumns().addAll(ID, Name, Date);

        TextField newDevice = new TextField();
        newDevice.setLayoutX(500);

        final VBox vbox = new VBox();
        vbox.setSpacing(5);
        vbox.setPadding(new Insets(10, 0, 0, 10));
        vbox.getChildren().addAll(label, table, newDevice);

        ((Group) secondScene.getRoot()).getChildren().addAll(vbox);

        Devices.setScene(secondScene);
        Devices.initModality(Modality.WINDOW_MODAL);
        Devices.initOwner(primaryStage);
        Devices.show();
    }
}
